#Rebecca Zaldivar
#November 9, 2020
#Pandigital

number = input("Enter a whole number: ")
count = 0

for num in range(10):

    if str(num) in number:
        count += 1
    else:
        break
if count == 10:
    
    print("This number is pandigital!")
else:
    print("This is not a pandigital number!")



