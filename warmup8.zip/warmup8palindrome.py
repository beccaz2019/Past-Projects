#Rebecca Zaldivar
#November 9, 2020
#Palindrome

phrase = input("Enter a phrase: ").upper()
clean = ''

for char in phrase:
    if char.isalpha():
        clean += char

if clean == '':
    print("This was not valid input.")

elif clean == clean[::-1]:
    print("This phrase is a palindrome!")
    
else:
    print("This phrase is not a palindrome!")